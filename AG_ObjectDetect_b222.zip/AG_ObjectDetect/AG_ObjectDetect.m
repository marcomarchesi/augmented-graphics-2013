//
//  AG_ObjectDetect.m
//  AG_ObjectDetect
//
//  Created by Marco Marchesi on 9/23/13.
//  Copyright (c) 2013 Marco Marchesi. All rights reserved.
//

#import "AG_ObjectDetect.h"

@implementation AG_ObjectDetect

@end
