//
//  EmObjectDetect.cpp
//  objectdetect
//
//  Created by Marco Marchesi on 10/17/13.
//  Copyright (c) 2013 Marco Marchesi. All rights reserved.
//

#include "EmObjectDetect.h"
#include "UIImage2OpenCV.h"


EmObjectDetect::EmObjectDetect()
:rng(12345)
,ksize_width(5)
,ksize_height(5)
,max_ksize_width(50)
,max_ksize_height(50)
,threshold1(25)
,threshold2(20)
,max_threshold1(100)
,max_threshold2(100)
,epsilon_factor(15)
,max_epsilon_factor(75)
,dilation_size(1)
,max_dilation_size(10)
{
    //focus window
	rect = cv::Rect(160,120,320,240);
}

vector<vector<cv::Point>> EmObjectDetect::image_load_elaboration(Mat sample)
{
    
	vector<vector<cv::Point>> largest_contour_load;
	Mat img;
    
    //
    
    resize(sample, img, cv::Size(480,640));
    img.convertTo(img, CV_LOAD_IMAGE_GRAYSCALE);
    
	if( !img.empty() )
	{
		// frame filtering
		GaussianBlur(img, img, cv::Size( (2*ksize_width)+1,(2*ksize_height)+1 ), 1.5, 1.5);
		Canny(img, img, threshold1, threshold2, 3, true);
        
		// Apply the dilation operation
		Mat dilation;
		Mat element = getStructuringElement(MORPH_ELLIPSE , cv::Size(2 * dilation_size + 1, 2 * dilation_size + 1), cv::Point(dilation_size, dilation_size));
		dilate(img, dilation, element);
		dilation_size=1; // dilation for "camera_acquisition_elaboration"
        
		
		// find the contours
        //TODO BETTER TO USE CHAIN_APPROX_SIMPLE
		findContours(dilation, contours_load, hierarchy_load, CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE);
        
        
        // find the contour of the largest area
		double area_max=100;
		int area_max_idx=0;
        
        
        
        //TODO join next for cycles
		for(unsigned i=0; i<contours_load.size(); i++)
			if( contourArea(Mat(contours_load[i])) > area_max )
			{
				area_max=contourArea(Mat(contours_load[i]));
				area_max_idx=i;
			}
        
        
		// Largest contour load copy
		largest_contour_load.push_back(contours_load[area_max_idx]);
        
		// Ogni contorno compare contemporaneamente a 2 livelli della gerarchia: la sua parte esterna risulta ad un livello gerarchico
		// pi˘ alto rispetto alla sua parte interna.
		for(unsigned i=0;i<contours_load.size();i++)
		{
			// Trovo la parte esterna, a livello gerarchico, del contorno pi˘ grande
			if(hierarchy_load[i][3]==area_max_idx)
			{
				for(unsigned j=0;j<contours_load.size();j++)
				{
					// Trovo la parte interna, a livello gerarchico, del contorno pi˘ grande  e da questa ne traccio i contorni innestati
					// Trovo solo i dettagli del contorno pi˘ grande (contorno grande escluso!)
					if(hierarchy_load[j][3]==i)
					{
						largest_contour_load.push_back(contours_load[j]);
					}
				}
			}
		}
        
        
    }
    NSLog(@"sample contours are %lu",largest_contour_load.size());
    return largest_contour_load;
}

Mat EmObjectDetect::matFromContours(vector<vector<cv::Point>> contours){
    
    Mat image = Mat::zeros(640,480,CV_8UC3);
    
    for(unsigned i=0; i<contours.size(); i++)
        drawContours(image, contours, i, Scalar(0,255,255), 1, 8);
    
    cv::cvtColor(image, image, CV_BGR2BGRA);
    return image;
    
}

Mat EmObjectDetect::camera_acquisition_elaboration(Mat inputFrame, vector<vector<cv::Point>> contour_unique_load)
{
    
	Mat src, temp;
    vector<vector<cv::Point>> largest_contour;
    
	// get a new frame from camera
    src = inputFrame;
    
	//cap >> src;
    
	if ( !src.empty() )
	{
		
		
		// create "Focus Source" window
		Mat roiImg;
		roiImg = src(rect);
        
        
        // setup image MARCO
//        int thresh = 100;
//        cv::cvtColor(roiImg, temp, CV_BGRA2GRAY);
//        cv::blur( temp, temp, cv::Size(3,3) );
//        cv::Canny( temp, temp, thresh, thresh*2, 3 );
//        cv::erode(temp, temp, cv::Mat(cv::Size(1, 1), CV_8UC1));
//        cv::dilate(temp ,temp, cv::Mat(cv::Size(1, 1), CV_8UC1));
	
        
		// frame filtering
		cvtColor(roiImg, temp, CV_RGB2GRAY);
		GaussianBlur(temp, temp, cv::Size( (2*ksize_width)+1,(2*ksize_height)+1 ), 1.5, 1.5);
		Canny(temp, temp, threshold1, threshold2, 3, true);
		
		// Apply the dilation operation
		Mat dilation;
		Mat element = getStructuringElement(MORPH_ELLIPSE , cv::Size(2 * dilation_size + 1, 2 * dilation_size + 1), cv::Point(dilation_size, dilation_size));
		dilate(temp, dilation, element);
		

		// find the contours
		findContours(dilation, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE);
		
//		// Contours Matrices Initialization
//		Mat drawing = Mat::zeros( temp.size(), CV_8UC3 );
//		
//		for(unsigned i=0; i<(contours.size()); i++)
//		{
//			// Define random color
//			color = Scalar(rng.uniform(0, 255), rng.uniform(0,255), rng.uniform(0,255));
//            
//			// Draw ALL contours
//			drawContours(drawing, contours, i, color, 1, 8, hierarchy);
//		}
        
		
        
        // -------------------------------------------------------------------------------------------------
		
		// find the contour of the largest area
		double area_max=100;
		int area_max_idx=0;
		for(unsigned i=0; i<contours.size(); i++)
			if( contourArea(Mat(contours[i])) > area_max )
			{
				area_max=contourArea(Mat(contours[i]));
				area_max_idx=i;
			}
        
		// Create a mask for largest contour to mask out that region from image.
		Mat mask = Mat::zeros(roiImg.size(), roiImg.type());
		// Create a mask for details contour to mask out that region from image.
		Mat mask_1 = Mat::zeros(roiImg.size(), roiImg.type());
		
		// At this point, mask has value of 255 for pixels within the contour and value of 0 for those not in contour.
		//drawContours(mask, contours, area_max_idx, Scalar(100,150,200), 1, 8, hierarchy, 0);
          drawContours(mask, contours, area_max_idx, Scalar(100,150,200), 1, 8);
        
		if(contours.size()>0)
			// Largest contour load copy
			largest_contour.push_back(contours[area_max_idx]);
        
		// Ogni contorno compare contemporaneamente a 2 livelli della gerarchia: la sua parte esterna risulta ad un livello gerarchico
		// pi˘ alto rispetto alla sua parte interna.
		for(unsigned i=0;i<contours.size();i++)
		{
			// Trovo la parte esterna, a livello gerarchico, del contorno pi˘ grande
			if(hierarchy[i][3]==area_max_idx)
			{
				for(unsigned j=0;j<contours.size();j++)
				{
					// Trovo la parte interna, a livello gerarchico, del contorno pi˘ grande  e da questa ne traccio i contorni innestati
					// Trovo solo i dettagli del contorno pi˘ grande (contorno grande escluso!)
					if(hierarchy[j][3]==i)
					{
						
						drawContours(mask_1, contours, j, Scalar(100,150,200), 1, 8, hierarchy, 0);
						// Copio i sottocontorni (dettagli) del contorno pi˘ grande
						largest_contour.push_back(contours[j]);
					}
				}
			}
		}
        
		vector<vector<cv::Point>> contour_one(1), contour_one_load(1);
        
		// Riunisco i contorni "selezionati" dall'immagine campione
		for(unsigned i=0;i<contour_unique_load.size();i++)
			for(unsigned j=0;j<contour_unique_load[i].size();j++)
				contour_one_load[0].push_back(contour_unique_load[i][j]);
		
		// Riunisco i contorni "selezionati" dal frame acquisito
		for(unsigned i=0;i<largest_contour.size();i++)
			for(unsigned j=0;j<largest_contour[i].size();j++)
				contour_one[0].push_back(largest_contour[i][j]);
        
        NSLog(@"em total contours aew %lu",contour_one[0].size());
        
		if(contours.size()>0)
			result=matchShapes(contour_one_load[0], contour_one[0], CV_CONTOURS_MATCH_I1, 0);
        
            
        Mat output = src;
        
        cv::Rect roi( cv::Point( 160, 120 ), cv::Size( 320, 240 ));
        Mat destinationROI = output( roi );
        mask.copyTo( destinationROI );
        
        return output;
	}else
        return src;
}


/*** Helper FUNCTION to find a cosine of angle between vectors from pt0->pt1 and pt0->pt2 ***/

double EmObjectDetect::angle(cv::Point pt1, cv::Point pt2, cv::Point pt0)
{
    double dx1 = pt1.x - pt0.x;
    double dy1 = pt1.y - pt0.y;
    double dx2 = pt2.x - pt0.x;
    double dy2 = pt2.y - pt0.y;
    return (dx1*dx2 + dy1*dy2)/sqrt((dx1*dx1 + dy1*dy1)*(dx2*dx2 + dy2*dy2) + 1e-10);
}

/*** FUNCTION -> distance (Euclidean) between these two points ***/

double EmObjectDetect::euclideanDist(cv::Point p, cv::Point q)
{
    cv::Point diff = p - q;
    return sqrt(diff.x*diff.x + diff.y*diff.y);
}
