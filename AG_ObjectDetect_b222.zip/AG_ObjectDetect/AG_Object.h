//
//  AG_Object.h
//  objectdetect
//
//  Created by Marco Marchesi on 9/27/13.
//  Copyright (c) 2013 Marco Marchesi. All rights reserved.
//

#ifndef __objectdetect__AG_Object__
#define __objectdetect__AG_Object__

#include <iostream>

using namespace cv;


typedef struct shapeDef{
    int index;
    std::vector<cv::Point> centroids;
    std::vector<std::vector<cv::Point> > contours;
    cv::vector<cv::Vec4i> hierarchy;
    
} shapeDef;

class AGObject{
    
    public:

    static float approxValue;
    
     
    static bool processFrame(const cv::Mat& inputFrame, cv::Mat& outputFrame, int const mode);

    static shapeDef shape(cv::Mat image);
    static cv::Mat objectDetect(cv::Mat image);
    static cv::Mat drawShape(shapeDef shape, bool draw_centroids, bool maxContour);
    static cv::Mat imageSegmentation(cv::Mat image);
    static std::vector<shapeDef> loadImageSample(int n);
    static double compareShapes(shapeDef *shape1,shapeDef *shape2);
    static int getMaxContour(shapeDef *shape);
    
    static double compareMaxObjects(cv::Mat image1,cv::Mat image2);
    
    static double euclideanDist(cv::Point p, cv::Point q);
    
    
    private:
    
    cv::Mat getROI(cv::Mat image, shapeDef *shape,int index,cv::Point *offset);
    
    std::vector<shapeDef> imageSamples;
    cv::Mat optimizedShape(cv::Mat image);
    

    //DEPRECATED
    //void getCentroid(cv::Mat image,shapeDef *shape,cv::Point offset);
    
    
    //YEAH!
    cv::Mat drawShapeAnotherWorld(cv::Mat image, shapeDef shape);
    
};
#endif /* defined(__objectdetect__AG_Object__) */
