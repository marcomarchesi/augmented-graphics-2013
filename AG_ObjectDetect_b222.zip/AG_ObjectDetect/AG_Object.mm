//
//  AG_Object.cpp
//  objectdetect
//
//  Created by Marco Marchesi on 9/27/13.
//  Copyright (c) 2013 Marco Marchesi. All rights reserved.
//

#include "AG_Object.h"
#include "AG_Quantize.h"
#include "AG_ColorDetect.h"
#include "UIImage2OpenCV.h"


float AGObject::approxValue = 0;

bool AGObject::processFrame(const cv::Mat& inputFrame, cv::Mat& outputFrame,int const mode){
    
    cv::Mat old_frame = cv::Mat(480,640,CV_8UC3);
    
    
    inputFrame.copyTo(old_frame);
    
    switch (mode) {
        case MODE_RGB:
        {
            outputFrame = inputFrame;
        }
            break;
        case MODE_SHAPE:
        {
//            shapeDef shape1 = AGObject::shape(inputFrame);
//            outputFrame = AGObject::drawShape(shape1,false,false);
//            cv::cvtColor(outputFrame, outputFrame, CV_BGR2BGRA);
            
            outputFrame = AGObject::objectDetect(inputFrame);
            cv::cvtColor(outputFrame, outputFrame, CV_BGR2BGRA);
        }
            break;
        case MODE_POSTER:
        {
            outputFrame = AG_Quantize::quantize(inputFrame);
        }
            
            break;
        case MODE_ROBUST_EDGE:
        {
            if (!old_frame.empty()) {
                
                shapeDef shape1 = AGObject::shape(old_frame);
                if (!inputFrame.empty()) {
                    inputFrame.copyTo(old_frame);
                    cv::Mat newFrame = AGObject::drawShape(shape1,false,false);
                    if (!newFrame.empty()){
                        shapeDef shape2 = AGObject::shape(newFrame);
                        outputFrame = AGObject::drawShape(shape2,false,false);
                        cv::cvtColor(outputFrame, outputFrame, CV_BGR2BGRA);
                    }
                }
            }
        }
            break;
        case MODE_COLOR:
        {
            shapeDef shape1 = AGObject::shape(inputFrame);
            outputFrame = AGObject::drawShape(shape1,false,false);
            cv::cvtColor(outputFrame, outputFrame, CV_BGR2BGRA);
        }
            break;
        case MODE_SEGMENTATION:
        {
            outputFrame = AGObject::imageSegmentation(inputFrame);
            
        }
            break;
        case MODE_COMPARE:
        {
            
            std::vector<shapeDef> imageSamples = AGObject::loadImageSample(4);
            double compare;
            shapeDef shapeFrame = AGObject::shape(inputFrame);
            
            for(int i=0;i<imageSamples.size();i++){
                compare = AGObject::compareShapes(&shapeFrame, &imageSamples[i]);
                if(compare < 0.05){
                    NSLog(@"it's an iphone4! %f",compare);
                    outputFrame = AGObject::drawShape(shapeFrame,false,true);
                    //setLabel(outputFrame, "ciao", shapeFrame.contours[0]);
                    cv::cvtColor(outputFrame, outputFrame, CV_BGR2BGRA);
                    
                }else{
                    NSLog(@"it's not an iphone4 %f",compare);
                    outputFrame = AGObject::drawShape(shapeFrame,false,true);
                    cv::cvtColor(outputFrame, outputFrame, CV_BGR2BGRA);
                }
            }
            
        }
            break;
        case MODE_EM:
        {
            
        }
            break;
        default:
            break;
    }
    
    return true;
}



std::vector<shapeDef> AGObject::loadImageSample(int n){
    
    std::vector<shapeDef> samples;
    
    UIImage *image_sample1 = [UIImage imageNamed:@"bottle03.jpg"];
    
    cv::Mat image1 =  [image_sample1 toMat];
    samples.push_back(AGObject::shape(image1));
    UIImage *image_sample2 = [UIImage imageNamed:@"bottle04.jpg"];
    cv::Mat image2 = [image_sample2 toMat];
    shapeDef shape2 = AGObject::shape(image2);
    samples.push_back(shape2);
    
    return  samples;
    
}


// NEW FUNCTION 22/10/13

Mat AGObject::objectDetect(Mat image){
    
    
    // setup image
    int thresh = 100;
    cv::cvtColor(image, image, CV_BGRA2GRAY);
    cv::blur( image, image, cv::Size(3,3) );
    cv::Canny( image, image, thresh, thresh*2, 3 );
    cv::erode(image, image, cv::Mat(cv::Size(1, 1), CV_8UC1));
    cv::dilate(image, image, cv::Mat(cv::Size(1, 1), CV_8UC1));
    
    
    cv::vector<cv::vector<cv::Point> > contours;
    cv::vector<cv::Vec4i> hierarchy;
    cv::findContours( image, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE, cv::Point(0, 0) );
    
    
    // find the contour of the largest area
    double area_max=0;
    int area_max_idx=0;
    for(unsigned i=0; i<contours.size(); i++)
        if( contourArea(Mat(contours[i])) > area_max )
        {
            area_max=contourArea(Mat(contours[i]));
            area_max_idx=i;
        }
    
    cv::vector<cv::vector<cv::Point>> rootContours;
    
    if(contours.size()>0){
        Moments mu;
        mu = moments(contours[area_max_idx]);
        Point2f centerOfMass0 = Point2f(image.cols/2, image.rows/2);
        //Point2f centerOfMass0 = Point2f(mu.m10/mu.m00, mu.m01/mu.m00); //centerOfMass of biggest contour
        
        for (int i = 0; i<hierarchy.size(); i++) {
            if(hierarchy[i][3] == -1)
            {
                //cv::Rect area = boundingRect(contours[i]);
                Moments mu;
                mu = moments(contours[i]);
                if(mu.m00>0){
                    Point2f centerOfMass = Point2f(mu.m10/mu.m00, mu.m01/mu.m00);
                    if(AGObject::euclideanDist(centerOfMass, centerOfMass0) < 45){
                        rootContours.push_back(contours[i]);
                        centerOfMass0 = centerOfMass;
                        for (int j=0; j<hierarchy.size(); j++) {
                            if(hierarchy[j][3] == i)
                                rootContours.push_back(contours[j]);
                        }
                    }
                }
            }
        }
    }
    
    cv::Mat newImage = cv::Mat::zeros(480, 640, CV_8UC3);
    cv::Scalar color = cv::Scalar(255,255,255);
    
    //only contours without parent
    for (int i=0;i<rootContours.size();i++)
        cv::drawContours( newImage, rootContours, i, color,1,8);

    NSLog(@"root/total is %lu/%lu",rootContours.size(),contours.size());
    
    return newImage;
    
}






shapeDef AGObject::shape(cv::Mat image){
    
    
   
    shapeDef shape1;
    
    int thresh = 100;
    
    cv::cvtColor(image, image, CV_BGRA2GRAY);
    cv::blur( image, image, cv::Size(3,3) );
    
    cv::Canny( image, image, thresh, thresh*2, 3 );
    
    cv::erode(image, image, cv::Mat(cv::Size(1, 1), CV_8UC1));
    cv::dilate(image, image, cv::Mat(cv::Size(1, 1), CV_8UC1));
    
    cv::vector<cv::vector<cv::Point> > contours;
    cv::vector<cv::Vec4i> hierarchy;
    
    //finding all contours in the image
    cv::findContours( image, contours, hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE, cv::Point(0, 0) );
    
    std::vector<std::vector<cv::Point> > contours_poly;
    for( int i = 0; i < contours.size(); i++ ) {
        
        cv::Mat output;
        cv::approxPolyDP(cv::Mat(contours[i]),output,1,false);
        double area0 = contourArea(output);
        if(area0 >0)
            contours_poly.push_back(output);
        
    }
    
    shape1.contours = contours_poly;
    shape1.hierarchy = hierarchy;
    cv::Point offset1;
    
    return shape1;
}

cv::Mat getROI(cv::Mat image,shapeDef *shape,int index,cv::Point *offset){
    //int max_contour_index = getMaxContour(shape);
    std::vector<cv::Point> contour;
    cv::Mat image0;
    
    if (shape->contours.size()>0){
        
        contour = shape->contours[index];
        cv::Rect bRect = cv::boundingRect(contour);
        image0 = image(bRect);
        offset->x = bRect.x;
        offset->y = bRect.y;
    }
    else{
        image0 = image;
        offset->x = 0;
        offset->y = 0;
    }
    return image0;
}

int AGObject::getMaxContour(shapeDef *shape1){
    
    int max_index = 0;
    double area,max_area = 0;
    
    for (int i=0; i< shape1->contours.size(); i++) {
        area = cv::contourArea(shape1->contours[i]);
        if (area >max_area) {
            max_area = area;
            max_index = i;
        }
        
    }
    
    return max_index;
    
}

//void getCentroid(cv::Mat image,shapeDef *shape,cv::Point offset){
//    
//    
//    cv::Point centroid = cv::Point(0,0);
//    std::vector<std::vector<cv::Point> > contours_poly;
//    for( int i = 0; i < shape->contours.size(); i++ ) {
//        
//        //cv::Mat output;
//        //cv::approxPolyDP(cv::Mat(contours[i]), output, 1, false );
//        double area0 = contourArea(shape->contours[i]);
//        if(area0 >0){
//            contours_poly.push_back(shape->contours[i]);
//            cv::Rect bRect = cv::boundingRect(shape->contours[i]);
//            centroid.x = bRect.x + (bRect.width / 2);
//            centroid.y = bRect.y + (bRect.height / 2);
//            shape->centroids.push_back(centroid);
//        }
//        
//    }
//    
//}


double AGObject::compareShapes(shapeDef *shape1,shapeDef *shape2){
    
    
    
    //compare all the contours in two shapes
    
    // merge all contours into one vector
    std::vector<cv::Point> merged_contour_points1;
    for (int i = 0; i < shape1->contours.size(); i++) {
        for (int j = 0; j < shape1->contours[i].size(); j++) {
            merged_contour_points1.push_back(shape1->contours[i][j]);
        }
    }
    
    std::vector<cv::Point> merged_contour_points2;
    for (int i = 0; i < shape2->contours.size(); i++) {
        for (int j = 0; j < shape2->contours[i].size(); j++) {
            merged_contour_points2.push_back(shape2->contours[i][j]);
        }
    }
    
    //int max_index_2 = getMaxContour(shape2);
    
    if((merged_contour_points1.size()>0) && (merged_contour_points2.size()>0)){
        double compare = cv::matchShapes(merged_contour_points1, merged_contour_points2,CV_CONTOURS_MATCH_I1,0);
        return compare;
    }else
        return 0;
    
    
}




double AGObject::compareMaxObjects(cv::Mat image1,cv::Mat image2){
    
    shapeDef shape1 = AGObject::shape(image1);
    int max_index_1 = AGObject::getMaxContour(&shape1);
    shapeDef shape2 = AGObject::shape(image2);
    int max_index_2 = AGObject::getMaxContour(&shape2);
    
    //NSLog(@"size 1 and size 2 are %lu %lu",shape1.contours.size(),shape2.contours.size());
    
    if((shape1.contours.size()==0) || (shape2.contours.size()==0))
        return -1;
    
    double compare = cv::matchShapes(shape1.contours[max_index_1], shape2.contours[max_index_2], CV_CONTOURS_MATCH_I1, 0);
    
    return compare;
    
}


cv::Mat AGObject::drawShape(shapeDef shape1,bool draw_centroids,bool maxContour){
    
    cv::Mat image = cv::Mat::zeros(480, 640, CV_8UC3);
    cv::Scalar picked_color = cv::Scalar(255,255,255);
    
    //if(maxContour)
        
    cv::RNG rng(12345);
    cv::Point offset1;
    cv::Scalar centroid_color;
    
    
    if(maxContour){
        int max_index = AGObject::getMaxContour(&shape1);
        cv::drawContours( image, shape1.contours, max_index, picked_color,1,8);
        
    }
    else{
        for( int i = 0; i< shape1.contours.size(); i++ )
        {
            
            
            cv::drawContours( image, shape1.contours, i, picked_color,1,8);
            
        }
        
        for ( int j = 0; j< shape1.centroids.size(); j++ ){
            if(draw_centroids){
                
                centroid_color = cvScalar( 0, 255, 0 );
                cv::circle(image,shape1.centroids[j],10, centroid_color);
                
            }
            
        }
    }
    return image;
}


cv::Mat AGObject::imageSegmentation(cv::Mat image){
    
    cv::Mat dst = cv::Mat::zeros(image.size(), image.type());
    shapeDef shape1 = AGObject::shape(image);
    int max_index = AGObject::getMaxContour(&shape1);
    cv::drawContours( dst, shape1.contours, max_index, cvScalar(255,255,255), CV_FILLED,8);
    
    dst &= image;
    return dst;
}




/*** FUNCTION -> distance (Euclidean) between these two points ***/

double AGObject::euclideanDist(cv::Point p, cv::Point q)
{
    cv::Point diff = p - q;
    return sqrt(diff.x*diff.x + diff.y*diff.y);
}



