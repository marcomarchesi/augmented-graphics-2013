//
//  EmObjectDetect.cpp
//  objectdetect
//
//  Created by Marco Marchesi on 10/17/13.
//  Copyright (c) 2013 Marco Marchesi. All rights reserved.
//

#include "EmObjectDetect.h"
#include "UIImage2OpenCV.h"
#include "AGConstants.h"

EmObjectDetect::EmObjectDetect()
:rng(12345)
,ksize_width(5)
,ksize_height(5)
,max_ksize_width(50)
,max_ksize_height(50)
,threshold1(20)
,threshold2(30)
,max_threshold1(100)
,max_threshold2(100)
,epsilon_factor(5)
,max_epsilon_factor(50)
,dilation_size(2)
,max_dilation_size(10)
,erosion_size(2)
,max_erosion_size(10)
{
    //focus window
	//rect = cv::Rect(160,120,320,240);
    rect = cv::Rect(0,0,640,480);
}

vector<vector<cv::Point> > EmObjectDetect::image_load_elaboration(Mat sample)
{
    
	vector<vector<cv::Point> > largest_contour_load;
	Mat img;
    
    //
    
    resize(sample, img, cv::Size(480,640));
    img.convertTo(img, CV_LOAD_IMAGE_GRAYSCALE);
    
	if( !img.empty() )
	{
		// frame filtering
        // Apply the erosion operation
		Mat erosion;
		Mat element = getStructuringElement( MORPH_ELLIPSE, cv::Size(erosion_size + 1, erosion_size + 1), cv::Point(erosion_size, erosion_size) );
		erode(img, erosion, element);
        
		// frame filtering
		GaussianBlur(erosion, img, cv::Size( (2*ksize_width)+1,(2*ksize_height)+1 ), 1.5, 1.5);
		Canny(img, img, threshold1, threshold2, 3, true);
        
		// Apply the dilation operation
		Mat dilation;
		element = getStructuringElement( MORPH_ELLIPSE , cv::Size(dilation_size + 1, dilation_size + 1), cv::Point(dilation_size, dilation_size) );
		dilate(img, dilation, element);
		//erosion_size=2;  // erosion for "camera_acquisition_elaboration"
		//dilation_size=2; // dilation for "camera_acquisition_elaboration"
        
		// find the contours
		findContours(img, contours_load, hierarchy_load, CV_RETR_TREE, CV_CHAIN_APPROX_NONE);
        
//		// Contours Matrices Initialization
//		Mat drawing_load = Mat::zeros(img.size(), CV_8UC3);
//		
//		for(unsigned i=0; i<(contours_load.size()); i++)
//		{
//			// Define random color
//			color = Scalar(rng.uniform(0, 255), rng.uniform(0,255), rng.uniform(0,255));
//            
//			// Draw ALL contours
//			drawContours(drawing_load, contours_load, i, color, 2, 8, hierarchy_load);
//		}
        
		// create "Contours_load" windows
		//window_output("Contours load", drawing_load);
        
        // -------------------------------------------------------------------------------------------------
        
		// find the contour of the largest area
		double area_max=100;
		int area_max_idx=0;
		for(unsigned i=0; i<contours_load.size(); i++)
			if( contourArea(Mat(contours_load[i])) > area_max )
			{
				area_max=contourArea(Mat(contours_load[i]));
				area_max_idx=i;
			}
        
		// Create a mask for largest contour to mask out that region from image.
		Mat mask = Mat::zeros(img.size(), img.type());
		// Create a mask for details contour to mask out that region from image.
		Mat mask_1 = Mat::zeros(img.size(), img.type());
        
		// At this point, mask has value of 255 for pixels within the contour and value of 0 for those not in contour.
		drawContours(mask, contours_load, area_max_idx, Scalar(255,255,255), 2, 8, hierarchy_load, 0);
        
		// Largest contour load copy
		largest_contour_load.push_back(contours_load[area_max_idx]);
        
		// Ogni contorno compare contemporaneamente a 2 livelli della gerarchia: la sua parte esterna risulta ad un livello gerarchico
		// pi˘ alto rispetto alla sua parte interna.
		for(unsigned i=0;i<contours_load.size();i++)
		{
			// Trovo la parte esterna, a livello gerarchico, del contorno pi˘ grande
			if(hierarchy_load[i][3]==area_max_idx)
			{
				for(unsigned j=0;j<contours_load.size();j++)
				{
					// Trovo la parte interna, a livello gerarchico, del contorno pi˘ grande  e da questa ne traccio i contorni innestati
					// Trovo solo i dettagli del contorno pi˘ grande (contorno grande escluso!)
					if(hierarchy_load[j][3]==i)
					{
						color = Scalar(rng.uniform(0, 255), rng.uniform(0,255), rng.uniform(0,255));
						drawContours(mask_1, contours_load, j, color, 2, 8, hierarchy_load, 0);
						// Copio i sottocontorni (dettagli) del contorno pi˘ grande
						largest_contour_load.push_back(contours_load[j]);
					}
				}
			}
		}
        
		// create "Largest Contour Load" windows
		//window_output("Largest Contour load", mask);
		//window_output("Child load", mask_1);
        
        // ------------------------------------------------------------------------------------------------
        
	}
	NSLog(@"sample contours are %lu",largest_contour_load.size());
    return largest_contour_load;
}

Mat EmObjectDetect::matFromContours(vector<vector<cv::Point> > contours){
    
    Mat image = Mat::zeros(640,480,CV_8UC3);
    
    for(unsigned i=0; i<contours.size(); i++)
        drawContours(image, contours, i, Scalar(0,255,255), 1, 8);
    
    cv::cvtColor(image, image, CV_BGR2BGRA);
    return image;
    
}

Mat EmObjectDetect::camera_acquisition_elaboration(Mat inputFrame, vector<vector<cv::Point> > contour_unique_load,int mode)
{
    
	Mat src, temp;
    vector<vector<cv::Point> > largest_contour;
    
	// get a new frame from camera
    src = inputFrame;
    
	//cap >> src;
    
	if ( !src.empty() )
	{
		
		
		// create "Focus Source" window
		Mat roiImg;
		roiImg = src(rect);
		
		
		// Apply the erosion operation
		Mat erosion;
		Mat element = getStructuringElement( MORPH_ELLIPSE, cv::Size(erosion_size + 1, erosion_size + 1), cv::Point(erosion_size, erosion_size) );
		erode(roiImg, erosion, element);
        
		// frame filtering
		cvtColor(erosion, temp, CV_RGB2GRAY);
		GaussianBlur(temp, temp, cv::Size( (2*ksize_width)+1,(2*ksize_height)+1 ), 1.5, 1.5);
		Canny(temp, temp, threshold1, threshold2, 3, true);
        
		// Apply the dilation operation
		Mat dilation;
		element = getStructuringElement( MORPH_ELLIPSE, cv::Size(dilation_size + 1, dilation_size + 1), cv::Point(dilation_size, dilation_size) );
		dilate(temp, dilation, element);

		// find the contours
		findContours(temp, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_NONE);
		
        // -------------------------------------------------------------------------------------------------
		
		// find the contour of the largest area
		double area_max=100;
		int area_max_idx=0;
		for(unsigned i=0; i<contours.size(); i++)
			if( contourArea(Mat(contours[i])) > area_max )
			{
				area_max=contourArea(Mat(contours[i]));
				area_max_idx=i;
			}
        
		// Create a mask for largest contour to mask out that region from image.
		Mat mask = Mat::zeros(roiImg.size(), roiImg.type());
		// Create a mask for details contour to mask out that region from image.

		if(contours.size()>0)
			// Largest contour load copy
			largest_contour.push_back(contours[area_max_idx]);
        
		// Ogni contorno compare contemporaneamente a 2 livelli della gerarchia: la sua parte esterna risulta ad un livello gerarchico
		// pi˘ alto rispetto alla sua parte interna.
		for(unsigned i=0;i<contours.size();i++)
		{
			// Trovo la parte esterna, a livello gerarchico, del contorno pi˘ grande
			if(hierarchy[i][3]==area_max_idx)
			{
				for(unsigned j=0;j<contours.size();j++)
				{
					// Trovo la parte interna, a livello gerarchico, del contorno pi˘ grande  e da questa ne traccio i contorni innestati
					// Trovo solo i dettagli del contorno pi˘ grande (contorno grande escluso!)
					if(hierarchy[j][3]==i)
					{
						
						drawContours(mask, contours, j, Scalar(100,150,200), 1, 8, hierarchy, 0);
						// Copio i sottocontorni (dettagli) del contorno pi˘ grande
						largest_contour.push_back(contours[j]);
					}
				}
			}
		}
        
        
		vector<vector<cv::Point> > contour_one(1), contour_one_load(1);
        
		// Riunisco i contorni "selezionati" dall'immagine campione
		for(unsigned i=0;i<contour_unique_load.size();i++)
			for(unsigned j=0;j<contour_unique_load[i].size();j++)
				contour_one_load[0].push_back(contour_unique_load[i][j]);
		
		// Riunisco i contorni "selezionati" dal frame acquisito
		for(unsigned i=0;i<largest_contour.size();i++)
			for(unsigned j=0;j<largest_contour[i].size();j++)
				contour_one[0].push_back(largest_contour[i][j]);
        
        //NSLog(@"em total contours are %lu",contour_one[0].size());
        
		if(contours.size()>0){
			result=matchShapes(contour_one_load[0], contour_one[0], CV_CONTOURS_MATCH_I1, 0);
            approxPolyDP(contours[area_max_idx], contours[area_max_idx], epsilon_factor, YES);
            fillConvexPoly(mask, contours[area_max_idx], Scalar(255,255,255));
            //drawContours(mask, contours, area_max_idx, Scalar(255,255,255), CV_FILLED);
            
            cvtColor(mask, mask, CV_RGB2GRAY);
            
            drawContours(mask, contour_one, 0, Scalar(255,255,255), CV_FILLED);
            // Apply the dilation operation
            		element = getStructuringElement( MORPH_ELLIPSE, cv::Size(3*dilation_size + 1, 3*dilation_size + 1), cv::Point(dilation_size, dilation_size) );
            		dilate(mask, mask, element);
            
                    vector<vector<cv::Point>> contour1;
                    cv::vector<cv::Vec4i> hierarchy1;
                   findContours(mask, contour1, hierarchy1, CV_RETR_TREE, CV_CHAIN_APPROX_NONE);
            //
            //        // find the contour of the largest area
            		double area_max2=100;
            		int area_max_idx2=0;
            		for(unsigned i=0; i<contour1.size(); i++)
            			if( contourArea(Mat(contour1[i])) > area_max2 )
            			{
            				area_max2=contourArea(Mat(contour1[i]));
            				area_max_idx2=i;
            			}
                    fillConvexPoly(mask, contour1[area_max_idx2], Scalar(255,255,255));

            
            
        }

        Mat output = src;
    
        //cv::Rect roi( cv::Point( 160, 120 ), cv::Size( 320, 240 ));
        cv::Rect roi( cv::Point( 0, 0), cv::Size( 640, 480 ));
        Mat destinationROI = output( roi );
        mask.copyTo( destinationROI );
        
        //mask &= src;
        cvtColor(mask, mask, CV_GRAY2BGRA);
        
        return mask;
	}else
        return src;
}


/*** Helper FUNCTION to find a cosine of angle between vectors from pt0->pt1 and pt0->pt2 ***/

double EmObjectDetect::angle(cv::Point pt1, cv::Point pt2, cv::Point pt0)
{
    double dx1 = pt1.x - pt0.x;
    double dy1 = pt1.y - pt0.y;
    double dx2 = pt2.x - pt0.x;
    double dy2 = pt2.y - pt0.y;
    return (dx1*dx2 + dy1*dy2)/sqrt((dx1*dx1 + dy1*dy1)*(dx2*dx2 + dy2*dy2) + 1e-10);
}

/*** FUNCTION -> distance (Euclidean) between these two points ***/

double EmObjectDetect::euclideanDist(cv::Point p, cv::Point q)
{
    cv::Point diff = p - q;
    return sqrt(diff.x*diff.x + diff.y*diff.y);
}
